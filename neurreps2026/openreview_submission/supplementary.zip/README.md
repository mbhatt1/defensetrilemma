# Supplementary Material

Anonymized supplementary material for the submission *"Truth Has a
Boundary. A Machine-Verified Topological Law for Models That Separate
Truth from Falsehood"* (NeurReps 2026, Proceedings Track).

Two components.

## HallucinationProofs/

The complete Lean 4 formalization. Every theorem and proposition in
the paper corresponds to a named, sorry-free Lean result. See
`HallucinationProofs/README.md` for build instructions and the full
paper-to-Lean map. To verify, install elan and run `lake build` in
that directory. The build completes with zero errors, zero warnings,
and no `sorry`, and the audited theorems reduce to exactly the three
standard kernel axioms.

## experiments/

The sub-billion-parameter experiments of Appendix C. `run_experiment.py`
reproduces `results.json` and the interpolation curves for GPT-2,
Pythia-410M, Qwen2.5-0.5B, and Phi-1.5 from the public
city-statement datasets
in `data/` (from the geometry-of-truth datasets of Marks and Tegmark).
`run_endogenous.py` reproduces `results_endogenous.json`, the
endogenous-confidence experiment (activation patching at the final
block) and the null baselines. `plot_figure.py` and
`plot_endogenous.py` regenerate the paper figures.
Requires torch, transformers, scikit-learn, scipy, pandas, numpy,
matplotlib. The theorems themselves depend on no experiment.
